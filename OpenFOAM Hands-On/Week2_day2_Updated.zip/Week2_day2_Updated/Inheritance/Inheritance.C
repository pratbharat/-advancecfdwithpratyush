/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) 2024 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Application
    Inheritance

Description


\*---------------------------------------------------------------------------*/

/*
Del p = (128*mu*Q*L)/(3.14*pow(dia,4));

Re = (4/3.14)*((rho*Q)/(dia*mu));

Common - Q,mu,dia

*/


#include "fvCFD.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

class Flow_in_Pipe // Base Class
{
    public:
    
    scalar mu,u,dia;
    
    
    void Input_value(scalar,scalar,scalar); // member function
    scalar Q();
    
};

class Calc_Pressure_Drop : public Flow_in_Pipe  // Derived Class  // Error is here // From Your side check how derived class is defined
{
    public:
    
    scalar  l;
    void Input_length(scalar e)
    {
        l = e;
    }
    scalar Pressure_drop();  
    
    // Constructor
   // Calc_Pressure_Drop(scalar, scalar,scalar,scalar);
   // Calc_Pressure_Drop(); // null
    
   
};

class Calc_Re: public Flow_in_Pipe  // Derived Class  // Derived Class  // Error is here // From Your side check how derived class is defined
{
    public:
    
    scalar rho;
    void Input_rho(scalar f)
    {
        rho = f;
    } 
    
    scalar Re();
   
};


void Flow_in_Pipe::Input_value(scalar a,scalar b,scalar c)
{
    mu = a;
    dia = b;
    u = c;
}


scalar Flow_in_Pipe::Q()
{
   return (3.14/4)*pow(dia,2)*u;
}

scalar Calc_Pressure_Drop::Pressure_drop()
{
   return ((128*mu*Q()*l)/(3.14*pow(dia,4)));
}

scalar Calc_Re::Re()
{
   return (4/3.14)*( (rho*Q() )/ (dia*mu));
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{

 
    Calc_Pressure_Drop Pipe1;
    Pipe1.Input_value(1e-5,0.02,0.05);
    Pipe1.Input_length(2.0);
    
    Calc_Re Pipe1_a;
    Pipe1_a.Input_value(1e-5,0.02,0.05);
    Pipe1_a.Input_rho(1.0);
    
    Info<<"The Pressure drop pipe 1 is:"<<Pipe1.Pressure_drop()<<endl;
    Info<<"The Re pipe 1 is:"<<Pipe1_a.Re()<<endl;
      
    
}



// ************************************************************************* //
