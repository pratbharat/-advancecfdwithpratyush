/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) 2024 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Application
    Operator

Description

\*---------------------------------------------------------------------------*/

#include "fvCFD.H"

/*
Addition of Complex number 

3+2i
5+1i

*/
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //
class Complex_Number
{
    public:
    
    scalar rp,ip;
    
    Complex_Number(scalar a, scalar b);
    Complex_Number();
    
    // Operator Overloading
    Complex_Number operator + (Complex_Number&);
    
};



Complex_Number Complex_Number::operator + (Complex_Number& rrrr)
{

    Complex_Number aaaa(rp + rrrr.rp, ip + rrrr.ip);
    
    return aaaa;
    
}

Complex_Number::Complex_Number(scalar a, scalar b)
{
    rp = a;
    ip = b;

}

Complex_Number::Complex_Number()
{
    rp = 5.11;
    ip = 1.2;

}


int main(int argc, char *argv[])
{
    //Complex_Number num1(3.25,2.44);
    Complex_Number num1;
    Complex_Number num2;
    
    
    Complex_Number summation = num1 + num2;
    
    Info<<"The summation is :"<<summation.rp<<"+"<<summation.ip<<"i"<<endl;
    

    return 0;
}


// ************************************************************************* //
