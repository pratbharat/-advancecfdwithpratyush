/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) 2024 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Application
    Poly

Description

\*---------------------------------------------------------------------------*/

/*

2 Types:

Compile Time - Function and Operator Overloading

Run Time - Virtual


*/




#include "fvCFD.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //


class Flow_in_Pipe // Base Class
{
    public:
    
    scalar mu,u,dia;
    
    
    void Input_value(scalar,scalar,scalar); // member function
    void Input_value(label,label,label); // member function
    void Input_value();
    
    virtual void display()
    {
       Info<<"The value of viscosity is:"<<mu<<endl;
       Info<<"The value of diameter is:"<<dia<<endl;
       Info<<"The value of velocity is:"<<u<<endl;
    
    }
    
    scalar Q();
    
};

class Calc_Pressure_Drop : public Flow_in_Pipe  // Derived Class  // Error is here // From Your side check how derived class is defined
{
    public:
    
    scalar  l;
    void Input_length(scalar e)
    {
        l = e;
    }
    scalar Pressure_drop();  

    void display()
    {
       Info<<"The value of viscosity is:"<<mu<<endl;
       Info<<"The value of diameter is:"<<dia<<endl;
       Info<<"The value of velocity is:"<<u<<endl;
       Info<<"The value of length is:"<<l<<endl;
    
    }

    
    // Constructor
   // Calc_Pressure_Drop(scalar, scalar,scalar,scalar);
   // Calc_Pressure_Drop(); // null
    
   
};

/*
class Calc_Re: public Flow_in_Pipe  // Derived Class  // Derived Class  // Error is here // From Your side check how derived class is defined
{
    public:
    
    scalar rho;
    void Input_rho(scalar f)
    {
        rho = f;
    } 
    
    scalar Re();
   
};
*/

void Flow_in_Pipe::Input_value(scalar a,scalar b,scalar c)
{
    mu = a;
    dia = b;
    u = c;
}

void Flow_in_Pipe::Input_value(label a,label b,label c)
{
    mu = a;
    dia = b;
    u = c;
}

void Flow_in_Pipe::Input_value()
{
    mu = 1;
    dia = 2.5;
    u = 0.25;
}


scalar Flow_in_Pipe::Q()
{
   return (3.14/4)*pow(dia,2)*u;
}

scalar Calc_Pressure_Drop::Pressure_drop()
{
   return ((128*mu*Q()*l)/(3.14*pow(dia,4)));
}



/*
scalar Calc_Re::Re()
{
   return (4/3.14)*( (rho*Q() )/ (dia*mu));
}
*/
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{

    /*
    Calc_Pressure_Drop Pipe1;
    Pipe1.Input_value(1e-5,0.02,0.05);
    Pipe1.Input_length(2.0);
    */
    
    //Info<<"The Pressure drop pipe 1 is:"<<Pipe1.Pressure_drop()<<endl;

    /*
    Flow_in_Pipe F1;
    F1.Input_value(1,5,2);
    F1.display();
    
    Flow_in_Pipe F2;
    F2.Input_value(1.222,5.222,2.22);
    F2.display();    
 
    Flow_in_Pipe F3;
    F3.Input_value();
    F3.display(); 
    
    */   
    Flow_in_Pipe * F1;
    Calc_Pressure_Drop P1;
    
    F1=&P1;
     
    P1.Input_value(1.222,5.222,2.22);
    P1.Input_length(3.2);
    F1->display();
    
}


// ************************************************************************* //
