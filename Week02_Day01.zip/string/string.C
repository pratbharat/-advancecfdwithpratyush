/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) 2024 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Application
    String

Description

\*---------------------------------------------------------------------------*/

#include "fvCFD.H"
#include "stringOps.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{
    /*
    string Testing;
    
    Testing = "    Welcome to 2nd week of OpenFoam Work Shop    "; 
    
    Info<<Testing<<endl;
    
    Info<<"trimLeft: " << stringOps::trimLeft(Testing) << endl;
    Info<<"trimRight: " << stringOps::trimRight(Testing) << endl;
    Info<<"trim: " << stringOps::trim(Testing) << endl;
    
    for (string::const_iterator i= Testing.begin(); i<= Testing.end();i++)
    {
		Info<<*i<<endl;	// * indicates pointer 
    }
    
	
    Info<<string(Testing).replace(" ","n")<<endl;    //Only Remove the first space character 
    Info<<string(Testing).replace(" ","")<<endl; // One way of removing spaces
    Info<<string(Testing).replaceAll("e","W")<<endl;  //Remove all the chr
    Info<<string(Testing).replaceAll(" ","")<<endl;   // The way of removing all the space char
    Info<<string(Testing).replaceAll("the","")<<endl;
  
   
    string Testing2= "This tutorial we are running in $FOAM_RUN. The user is from $HOME." ;
    Info<<Testing2<<endl;
    Info<<Testing2.expand()<<endl;  // expand the name space
    */
   
    /*
    dictionary dict;
    dict.add("OF","It means OpenFoam 7");
    
    dictionary subdict; 
    subdict.add("value1","val1");
    subdict.add("value2",3);
    
    dict.add("FOAM_RUN",subdict);
    
    Info<<dict<<endl;
    */
    
    /*
    dictionary dict2;
    dictionary subdict2,subdict3;
    subdict2.add("type","fixedValue");
    subdict2.add("value","uniform 0");
    
    subdict3.add("type","zeroGradient");
    //subdict2.add("value","uniform 0");    
    
    dict2.add("inlet",subdict2); 
    dict2.add("outlet",subdict3); 
    
    Info<<dict2<<endl;
    
    */
    /*
    string Testing3("~OpenFOAM/controlDict");
    Info<<Testing3<<" is "<<Testing3.expand()<<endl;
    
    
    //replace controlDict with "newControl"
    {
        string::size_type i = Testing3.rfind('/'); // If / is not present in the string; i=-1;

        if (i == string::npos)  //string::npos =-1
        {
            Testing3 = "newControl";
        }
        else
        {
            // this uses the std::string::replace
            Testing3.replace(i+1, string::npos, "newControl");
        }
        Info<< "After replacement: " << Testing3 << endl;

        // do another replace
        // this uses the Foam::string::replace
        Testing3.replace("openfoam7", "openFoam7");
     }
     
    Info<<"After replacement: "<<Testing3<<endl;
    */   
       
   
    string s;
    Sin.getLine(s);

    string s2(s.expand());

    cout<< "output string with " << s2.length() << " characters\n";
    cout<< "cout <<  >" << s2 << "<\n";
    Info<< "Info <<  >" << s2 << "<\n";
    Info<< "hash:" << hex << string::hash()(s2) << endl;   
    Info<< "End\n" << endl;
    

    return 0;
}


// ************************************************************************* //
