/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) 2024 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Application
    Class

Description

\*---------------------------------------------------------------------------*/
/*
Del p = (128*mu*Q*L)/(3.14*pow(dia,4))
*/
#include "fvCFD.H"

class Calc_Pressure_Drop
{
    public:
    
    scalar mu;
    //void Input_value(scalar, scalar,scalar,scalar); // member function
    
    scalar Pressure_drop();  
    
    // Constructor
    Calc_Pressure_Drop(scalar, scalar,scalar,scalar);
    Calc_Pressure_Drop(); // null
    
    private:
    
    scalar  dia;  // data member
    scalar u, l;
    
    
    scalar Q();
    
};
/*
void Calc_Pressure_Drop::Input_value(scalar a, scalar b,scalar c,scalar d)
{
    mu = a;
    dia = b;
    u = c;
    l = d;

}
*/

Calc_Pressure_Drop::Calc_Pressure_Drop(scalar a, scalar b,scalar c,scalar d)
{
    mu = a;
    dia = b;
    u = c;
    l = d;

}

Calc_Pressure_Drop::Calc_Pressure_Drop()
{
    mu = 1e-4;
    dia = 0.25;
    u = 2.5;
    l = 3.0;

}


scalar Calc_Pressure_Drop::Q()
{
   return (3.14/4)*pow(dia,2)*u;
}

scalar Calc_Pressure_Drop::Pressure_drop()
{
   return ((128*mu*Q()*l)/(3.14*pow(dia,4)));
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{

    /*
    Calc_Pressure_Drop Pipe1(1e-5, 0.1,1.0,2.0);
    //Pipe1.mu;
    
    
    Info<<"Case 1: Pressure drop through pipe 1 :"<<Pipe1.Pressure_drop()<<endl;
    Info<<"Case 1: mu 1 :"<<Pipe1.mu<<endl;
    
    
    Calc_Pressure_Drop Pipe2;
    Info<<"Case 2: Pressure drop through pipe 2 :"<<Pipe2.Pressure_drop()<<endl;  
    
    */ 
    
    // Pointer - variable only but contains memory of the defined variable
    
    /*
    scalar a = 5.5;
    scalar * x;
    
    x=&a;
    
    Info<<"a is :"<<a<<endl;  
    Info<<"a is :"<<*x<<endl;  
     
    */
    
    Calc_Pressure_Drop Pipe1;
    Calc_Pressure_Drop * pointer1;
    
    pointer1 = &Pipe1;
    
    Info<<"Case 2: Pressure drop through pipe 1 :"<<pointer1->Pressure_drop()<<endl; 
    Info<<"Case 3: Pressure drop through pipe 1 :"<<(* pointer1).Pressure_drop()<<endl;   
    
    
    
}


// ************************************************************************* //
