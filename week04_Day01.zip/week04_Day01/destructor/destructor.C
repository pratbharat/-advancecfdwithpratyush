/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) 2024 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Application
    destructor

Description

\*---------------------------------------------------------------------------*/

#include "fvCFD.H"

class Test {
public:
    // User-Defined Constructor
    Test() { Info << "\n Constructor executed"<<endl; }

    // User-Defined Destructor
    ~Test() { Info << "\nDestructor executed"<<endl; }
};


/*
 * Destructor is an instance member function that is invoked automatically whenever an object is going to be destroyed. 
 * Meaning, a destructor is the last function that is going to be called before an object is destroyed. 
 * 
 * Characteristics of a Destructor
	1. A destructor is also a special member function like a constructor. Destructor destroys the class objects created by the constructor. 
	2. Destructor has the same name as their class name preceded by a tilde (~) symbol.
	3. It is not possible to define more than one destructor.
	4. The destructor is only one way to destroy the object created by the constructor. Hence, destructor cannot be overloaded.
	5. It cannot be declared static or const.
	6. Destructor neither requires any argument nor returns any value.
	7. It is automatically called when an object goes out of scope. 
	8. Destructor release memory space occupied by the objects created by the constructor.
	9. In destructor, objects are destroyed in the reverse of an object creation.
 */ 

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{

	Test test;
    Info<< "End\n" << endl;

    return 0;
}


// ************************************************************************* //
