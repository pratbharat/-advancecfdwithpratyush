// Include OpenFOAM-specific header for OS-dependent operations, providing system-specific functionality.
#include "OSspecific.H"

// Include OpenFOAM's scalar type definition header, which defines scalar-related operations.
#include "scalar.H"

// Include OpenFOAM's input/output stream definitions, used for logging and stream operations.
#include "IOstreams.H"

// Include OpenFOAM's Dictionary class, which is a key-value storage container.
#include "Dictionary.H"

// Include OpenFOAM's pointer-based Dictionary class, which stores pointers to objects.
#include "PtrDictionary.H"

// Use the Foam namespace, which encapsulates all OpenFOAM functionality.
using namespace Foam;

// Define a class `ent` that inherits from OpenFOAM's `Dictionary<ent>::link` to link dictionary entries.
class ent
:
    public Dictionary<ent>::link
{
    // Private member variables: keyword of type `word` (a string in OpenFOAM) and an integer `i_`.
    word keyword_;
    int i_;

public:
    // Constructor that initializes `keyword_` and `i_` using the given arguments.
    ent(const word& keyword, int i)
    :
        keyword_(keyword),
        i_(i)
    {}

    // Method to return the keyword associated with this entry.
    const word& keyword() const
    {
        return keyword_;
    }

    // Overloaded friend function for outputting the content of `ent` to an output stream.
    // This allows `ent` objects to be printed using OpenFOAM's output streams.
    friend Ostream& operator<<(Ostream& os, const ent& e)
    {
        os  << e.keyword_ << ' ' << e.i_ << endl; // Output the keyword and integer value.
        return os;
    }
};

// Define a class `Scalar` to represent a scalar value, with a private scalar member.
class Scalar
{
    scalar data_; // Private member to store the scalar value.

public:
    // Default constructor that initializes the scalar value to 0.
    Scalar()
    :
        data_(0)
    {}

    // Constructor that initializes the scalar value with a given `val`.
    Scalar(scalar val)
    :
        data_(val)
    {}

    // Destructor that logs when a Scalar object is deleted, showing its value.
    ~Scalar()
    {
        Info << "delete Scalar: " << data_ << endl;
    }

    // Overloaded friend function for outputting the Scalar to an output stream.
    friend Ostream& operator<<(Ostream& os, const Scalar& val)
    {
        os << val.data_; // Output the scalar value.
        return os;
    }
};

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //
// Main program:

int main(int argc, char *argv[])
{
    // Dynamically allocate a new Dictionary of `ent` pointers and get a reference to it.
    Dictionary<ent>* dictPtr = new Dictionary<ent>;
    Dictionary<ent>& dict = *dictPtr;

    // Loop to create 10 `ent` objects and add them to the dictionary.
    for (int i = 0; i < 10; i++)
    {
        // Create a new `ent` object with a keyword "ent" followed by the index number and the index value.
        ent* ePtr = new ent(word("ent") + name(i), i);
        // Append the `ent` object to the dictionary using its keyword.
        dict.append(ePtr->keyword(), ePtr);
        // Move the newly added entry up in the dictionary to maintain order or priority.
        dict.swapUp(ePtr);
    }

    // Output the contents of the dictionary to the log.
    Info << dict << endl;

    // Move the first entry of the dictionary down by one position.
    dict.swapDown(dict.first());

    // Iterate through all constant entries in the dictionary and print them.
    forAllConstIter(Dictionary<ent>, dict, iter)
    {
        Info << "element : " << *iter;
    }

    // Output all keys in the dictionary.
    Info << "keys: " << dict.toc() << endl;

    // Delete the dynamically allocated dictionary to free memory.
    delete dictPtr;

    // Create a new Dictionary object `dict2` to store `ent` objects.
    Dictionary<ent> dict2;

    // Repeat the process of creating and inserting `ent` objects into `dict2`.
    for (int i = 0; i < 10; i++)
    {
        ent* ePtr = new ent(word("ent") + name(i), i);
        dict2.append(ePtr->keyword(), ePtr);
        dict2.swapUp(ePtr);
    }

    // Output the contents of `dict2`.
    Info << "dict:\n" << dict2 << endl;

    Info << nl << "Testing transfer: " << nl << endl;
    // Output the original state of `dict2`.
    Info << "original: " << dict2 << endl;

    // Create a new empty Dictionary `newDict` and transfer the contents of `dict2` to it.
    Dictionary<ent> newDict;
    newDict.transfer(dict2);

    // Output the state of `dict2` and `newDict` after the transfer.
    Info << nl << "source: " << dict2 << nl
         << "keys: " << dict2.toc() << nl
         << "target: " << newDict << nl
         << "keys: " << newDict.toc() << endl;

    // Create a `PtrDictionary` to store pointers to `Scalar` objects.
    PtrDictionary<Scalar> scalarDict;
    for (int i = 0; i < 10; i++)
    {
        // Create a key "ent" with the index number and insert a new Scalar object.
        word key("ent" + name(i));
        scalarDict.insert(key, new Scalar(1.3 * i));
    }

    // Output the contents of `scalarDict`.
    Info << nl << "scalarDict1: " << endl;
    forAllConstIter(PtrDictionary<Scalar>, scalarDict, iter)
    {
        Info << " = " << iter() << endl;
    }

    // Create another `PtrDictionary` for Scalar objects and insert more entries.
    PtrDictionary<Scalar> scalarDict2;
    for (int i = 8; i < 15; i++)
    {
        word key("ent" + name(i));
        scalarDict2.insert(key, new Scalar(1.3 * i));
    }

    // Output the contents of `scalarDict2`.
    Info << nl << "scalarDict2: " << endl;
    forAllConstIter(PtrDictionary<Scalar>, scalarDict2, iter)
    {
        Info << "elem = " << *iter << endl;
    }

    // Transfer entries from `scalarDict2` to `scalarDict`.
    scalarDict.transfer(scalarDict2);

    // Look up the `Scalar` object associated with key "ent8".
    Scalar* p = scalarDict.lookupPtr("ent8");

    // This code is commented out because it does not work as intended.
    // Scalar* q = scalarDict.remove("ent10");

    // Check if the lookup was successful and print the result.
    if (p)
    {
        Info << "found: " << *p << endl;
    }
    else
    {
        Info << "no p: " << endl;
    }

    // Clear all entries from `scalarDict`.
    scalarDict.clear();

    // This line is commented out as it refers to an undefined iterator.
    // Info<< " = " << *iter << endl;

    // Print a completion message to the log.
    Info << nl << "Done." << endl;
    return 0; // Exit the program.
}
