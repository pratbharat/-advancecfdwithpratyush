/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) 2024 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Application
    friend_function

Description

\*---------------------------------------------------------------------------*/

#include "fvCFD.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //


/*
 If a function is defined as a friend function in C++, then the protected and private data of a class can be accessed using the function.
 By using the keyword friend compiler knows the given function is a friend function.
 
 
 Characteristics of a Friend function:

	1.The function is not in the scope of the class to which it has been declared as a friend.
	2.It cannot be called using the object as it is not in the scope of that class.
	3.It can be invoked like a normal function without using the object.
	4.It cannot access the member names directly and has to use an object name and dot membership operator with the member name.
	5.It can be declared either in the private or the public part. 
 
 */


class Box    
{    
    private:    
        scalar length;    
    public:    
        Box(): length(0) { }    
        friend scalar printLength(Box); //friend function    
};    
scalar printLength(Box b)    
{    
   b.length += 10;    
    return b.length;    
}    

int main(int argc, char *argv[])
{
    Box b;    
    Info<<"Length of box: "<< printLength(b)<<endl;    
    Info<< "End\n" << endl;

    return 0;
}


/* Another example try yourself: 
 
 class Box {
private:
    double length;

public:
    // Constructor
    Box(double len) : length(len) {}

    // Member function to set length
    void setLength(double len) {
        length = len;
    }

    // Member function to get length
    double getLength() const {
        return length;
    }

    // Friend function declaration
    friend double getLengthFriend(Box box);
};

// Friend function definition
double getLengthFriend(Box box) {
    // Accessing the private member 'length' directly
    return box.length;
}

In main function:

Box box1(10.0);

    // Using member function to get length
    cout << "Length using member function: " << box1.getLength() << endl;

    // Using friend function to get length
    cout << "Length using friend function: " << getLengthFriend(box1) << endl;


  * /

// ************************************************************************* //
